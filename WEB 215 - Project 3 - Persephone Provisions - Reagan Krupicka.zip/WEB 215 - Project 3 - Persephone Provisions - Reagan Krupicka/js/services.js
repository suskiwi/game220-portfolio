$(document).ready(function () {
    // Toggle accordion content on heading click
    $("#services h3").on("click", function () {
        $(this).toggleClass("active");
        $(this).next(".accordion-content").slideToggle();
    });

    // When the 'Learn more' link is clicked, show a popup
    $(".accordion-content").on("click", ".service-link", function(e) {
        e.preventDefault();
        alert("This service is coming soon!");
    });
});
