document.getElementById("calc-form").addEventListener("submit", function (event) {
    event.preventDefault();
    const weight = parseFloat(document.getElementById("weight").value);
    const distance = parseFloat(document.getElementById("distance").value);
    const deliveryType = document.getElementById("delivery-type").value;

    let cost = weight * distance * (deliveryType === "express" ? 5 : 1);
    document.getElementById("result").innerText = `Estimated Cost: ${cost} credits`;
});
