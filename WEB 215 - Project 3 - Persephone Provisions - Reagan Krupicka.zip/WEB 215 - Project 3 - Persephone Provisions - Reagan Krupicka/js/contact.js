document.getElementById("contact-form").addEventListener("submit", function (event) {
    const email = document.getElementById("email").value;
    if (!email.includes("@")) {
        event.preventDefault();
        alert("Please enter a valid email.");
    }
});
