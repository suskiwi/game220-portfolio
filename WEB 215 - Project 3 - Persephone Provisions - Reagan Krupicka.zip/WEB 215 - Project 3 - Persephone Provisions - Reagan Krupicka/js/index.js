function typeEffect(element, text, speed) {
    let i = 0;
    function typeChar() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(typeChar, speed);
        }
    }
    element.innerHTML = ''; // Clear text first
    typeChar();
}

$(document).ready(function () {
    // Slider
    let currentSlide = 0;
    const slides = $(".slide");
    slides.hide();
    $(slides[currentSlide]).show();

    setInterval(() => {
        $(slides[currentSlide]).fadeOut();
        currentSlide = (currentSlide + 1) % slides.length;
        $(slides[currentSlide]).fadeIn();
    }, 3000);

    // Typing animation
    const header = document.querySelector("header h1");
    const headerText = header.textContent;
    typeEffect(header, headerText, 75);
});
