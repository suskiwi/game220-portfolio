import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShoppingListScreen extends StatefulWidget {
  @override
  _ShoppingListScreenState createState() => _ShoppingListScreenState();
}

class _ShoppingListScreenState extends State<ShoppingListScreen> {
  final TextEditingController _itemController = TextEditingController();
  List<String> shoppingList = [];

  @override
  void initState() {
    super.initState();
    loadShoppingList();
  }

  Future<void> loadShoppingList() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      shoppingList = prefs.getStringList('shoppingList') ?? [];
    });
  }

  Future<void> addItem() async {
    if (_itemController.text.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        shoppingList.add(_itemController.text);
        prefs.setStringList('shoppingList', shoppingList);
      });
      _itemController.clear();
    }
  }

  Future<void> removeItem(int index) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      shoppingList.removeAt(index);
      prefs.setStringList('shoppingList', shoppingList);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shopping List'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _itemController,
              decoration: InputDecoration(
                labelText: 'Add an item',
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: addItem,
                ),
              ),
            ),
            SizedBox(height: 16.0),
            Expanded(
              child: ListView.builder(
                itemCount: shoppingList.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      title: Text(shoppingList[index]),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => removeItem(index),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
