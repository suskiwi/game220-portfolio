import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'favorites_screen.dart';
import 'shopping_list_screen.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(RecipeFinderApp());
}

class RecipeFinderApp extends StatefulWidget {
  @override
  _RecipeFinderAppState createState() => _RecipeFinderAppState();
}

class _RecipeFinderAppState extends State<RecipeFinderApp> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    RecipeFinderHome(),
    FavoritesScreen(),
    ShoppingListScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pantry Pal',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        textTheme:
            GoogleFonts.lobsterTextTheme(), // Apply Lobster font globally
        scaffoldBackgroundColor: Colors.grey[100],
        appBarTheme: AppBarTheme(
          color: Colors.teal,
          titleTextStyle: GoogleFonts.lobster(
            textStyle: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.teal,
            foregroundColor: Colors.white,
            textStyle: GoogleFonts.lobster(
              textStyle: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.teal),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.teal, width: 2.0),
          ),
        ),
      ),
      home: Scaffold(
        body: _screens[_selectedIndex],
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          selectedItemColor: Colors.teal,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.favorite),
              label: 'Favorites',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart),
              label: 'Shopping List',
            ),
          ],
        ),
      ),
    );
  }
}

class RecipeFinderHome extends StatefulWidget {
  @override
  _RecipeFinderHomeState createState() => _RecipeFinderHomeState();
}

class _RecipeFinderHomeState extends State<RecipeFinderHome> {
  final TextEditingController _ingredientController = TextEditingController();
  List recipes = [];
  bool isLoading = false;

  Future<void> fetchRecipes(String ingredients) async {
    final apiUrl = 'https://api.spoonacular.com/recipes/complexSearch';
    final apiKey =
        'f48dee5104534b8cb0ed785d31dab371'; // Replace with your Spoonacular API key

    setState(() {
      isLoading = true;
    });

    try {
      final response = await http
          .get(Uri.parse('$apiUrl?query=$ingredients&apiKey=$apiKey'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          recipes = data['results'];
        });
      } else {
        throw Exception('Failed to load recipes');
      }
    } catch (e) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Error'),
          content: Text('Could not fetch recipes. Please try again later.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK'),
            ),
          ],
        ),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pantry Pal'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _ingredientController,
              decoration: InputDecoration(
                labelText: 'Enter Ingredients (comma-separated)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                if (_ingredientController.text.isNotEmpty) {
                  fetchRecipes(_ingredientController.text);
                }
              },
              child: Text('Find Recipes'),
            ),
            SizedBox(height: 16.0),
            if (isLoading) CircularProgressIndicator(),
            if (!isLoading && recipes.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: recipes.length,
                  itemBuilder: (context, index) {
                    final recipe = recipes[index];
                    return Card(
                      child: ListTile(
                        title: Text(recipe['title']),
                        trailing: Image.network(
                          recipe['image'],
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                        ),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  RecipeDetailScreen(recipe: recipe),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class RecipeDetailScreen extends StatefulWidget {
  final Map recipe;

  RecipeDetailScreen({required this.recipe});

  @override
  _RecipeDetailScreenState createState() => _RecipeDetailScreenState();
}

class _RecipeDetailScreenState extends State<RecipeDetailScreen> {
  Map<String, dynamic> recipeDetails = {};
  bool isLoading = true;
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
    fetchRecipeDetails();
    checkIfFavorite();
  }

  Future<void> fetchRecipeDetails() async {
    final apiKey =
        'f48dee5104534b8cb0ed785d31dab371'; // Replace with your Spoonacular API key
    final recipeId = widget.recipe['id'];

    final url =
        'https://api.spoonacular.com/recipes/$recipeId/information?apiKey=$apiKey';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        setState(() {
          recipeDetails = json.decode(response.body);
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load recipe details');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Error fetching recipe details. Please try again.')),
      );
    }
  }

  Future<void> checkIfFavorite() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];
    String recipeJson = json.encode(widget.recipe);

    setState(() {
      isFavorite = favorites.contains(recipeJson);
    });
  }

  Future<void> toggleFavorite() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> favorites = prefs.getStringList('favorites') ?? [];
    String recipeJson = json.encode(widget.recipe);

    setState(() {
      if (favorites.contains(recipeJson)) {
        favorites.remove(recipeJson);
        isFavorite = false;
      } else {
        favorites.add(recipeJson);
        isFavorite = true;
      }
    });

    await prefs.setStringList('favorites', favorites);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(
              isFavorite ? 'Added to Favorites' : 'Removed from Favorites')),
    );
  }

  // Function to strip HTML tags from the instructions
  String stripHtmlTags(String html) {
    return html.replaceAll(RegExp(r'<[^>]*>'), '');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.recipe['title']),
        actions: [
          IconButton(
            icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border),
            onPressed: toggleFavorite,
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.network(widget.recipe['image']),
                    SizedBox(height: 16.0),
                    Text(
                      widget.recipe['title'],
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      'Ingredients:',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8.0),
                    ...List<Widget>.from(
                      recipeDetails['extendedIngredients'].map(
                        (ingredient) => Text('- ${ingredient['original']}'),
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Text(
                      'Instructions:',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8.0),
                    Text(
                      stripHtmlTags(recipeDetails['instructions'] ??
                          'No instructions available.'),
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
