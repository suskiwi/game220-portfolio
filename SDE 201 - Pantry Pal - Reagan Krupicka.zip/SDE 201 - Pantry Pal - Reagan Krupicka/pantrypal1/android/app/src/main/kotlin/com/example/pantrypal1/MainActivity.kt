package com.example.pantrypal1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
