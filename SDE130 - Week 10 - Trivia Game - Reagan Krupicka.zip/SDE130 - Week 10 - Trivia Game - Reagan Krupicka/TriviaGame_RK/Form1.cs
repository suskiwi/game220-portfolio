namespace TriviaGame_RK
{
    public partial class triviaGameForm : Form
    {
        // variables
        private List<TriviaQuestion> questions = new List<TriviaQuestion>();
        private int currentQuestionIndex = 0;
        private int player1Score = 0;
        private int player2Score = 0;
        private int currentPlayer = 1;

        public triviaGameForm()
        {
            InitializeComponent();
            LoadQuestions();
            DisplayQuestion();
        }

        private void LoadQuestions()
        {
            // Triva questions, answer, answer, answer, answer, number of correct answer
            questions.Add(new TriviaQuestion("How long is a year on Mars?", "550 Earth days", "498 Earth days", "126 Earth days", "687 Earth days", 4));
            questions.Add(new TriviaQuestion("What is the largest ocean?", "Atlantic", "Indian", "Pacific", "Arctic", 3));
            questions.Add(new TriviaQuestion("Which planet has rings?", "Venus", "Mars", "Saturn", "Earth", 3));
            questions.Add(new TriviaQuestion("What gas do plants breathe in?", "Oxygen", "Nitrogen", "Hydrogen", "Carbon Dioxide", 4));
            questions.Add(new TriviaQuestion("What is H2O?", "Hydrogen", "Oxygen", "Water", "Helium", 3));
            questions.Add(new TriviaQuestion("Who painted the Mona Lisa?", "Da Vinci", "Van Gogh", "Picasso", "Michelangelo", 1));
            questions.Add(new TriviaQuestion("Which is a prime number?", "6", "8", "9", "7", 4));
            questions.Add(new TriviaQuestion("How many continents?", "5", "6", "7", "8", 3));
            questions.Add(new TriviaQuestion("Fastest land animal?", "Cheetah", "Lion", "Antelope", "Horse", 1));
            questions.Add(new TriviaQuestion("What color are bananas?", "Blue", "Green", "Red", "Yellow", 4));
        }

        private void DisplayQuestion()
        {
            //displays question in label and answers on buttons
            if (currentQuestionIndex < questions.Count)
            {
                var q = questions[currentQuestionIndex];
                question_lbl.Text = $"Player {currentPlayer}, {q.Question}";
                answerBtn_1.Text = q.Answers[0];
                answerBtn_2.Text = q.Answers[1];
                answerBtn_3.Text = q.Answers[2];
                answerBtn_4.Text = q.Answers[3];
            }
            else
            {
                ShowResults();
            }
        }

        private void AnswerQuestion(int answerSelected)
        {
            //after user answers it records if score if user got correct answer or not then displays the next question
            var q = questions[currentQuestionIndex];
            if (answerSelected == q.CorrectAnswer)
            {
                if (currentPlayer == 1)
                    player1Score++;
                else
                    player2Score++;
            }

            currentQuestionIndex++;

            if (currentQuestionIndex == 5)
                currentPlayer = 2;

            DisplayQuestion();
        }

        private void ShowResults()
        {
            // displays results of who won the game
            string winner = player1Score > player2Score ? "Player 1 wins!" :
                            player2Score > player1Score ? "Player 2 wins!" :
                            "It�s a tie!";
            MessageBox.Show($"Final Scores:\nPlayer 1: {player1Score}\nPlayer 2: {player2Score}\n\n{winner}");
        }

        // sets which button goes to which answer
        private void answerBtn_1_Click(object sender, EventArgs e) => AnswerQuestion(1);
        private void answerBtn_2_Click(object sender, EventArgs e) => AnswerQuestion(2);
        private void answerBtn_3_Click(object sender, EventArgs e) => AnswerQuestion(3);
        private void answerBtn_4_Click(object sender, EventArgs e) => AnswerQuestion(4);



        private void reset_btn_Click(object sender, EventArgs e)
        {
            // resets game for new match
            currentQuestionIndex = 0;
            player1Score = 0;
            player2Score = 0;
            currentPlayer = 1;
            DisplayQuestion();
        }

        private void ext_btn_Click(object sender, EventArgs e)
        {
            //exits application
            this.Close();
        }
    }

    public class TriviaQuestion
    {
        // gets ans sets questions, answers, and correct answer
        public string Question { get; set; }
        public string[] Answers { get; set; }
        public int CorrectAnswer { get; set; }

        public TriviaQuestion(string question, string ans1, string ans2, string ans3, string ans4, int correctAnswer)
        {
            Question = question;
            Answers = new string[] { ans1, ans2, ans3, ans4 };
            CorrectAnswer = correctAnswer;
        }
    }
}
