﻿namespace TriviaGame_RK
{
    partial class triviaGameForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(triviaGameForm));
            titletxtlbl = new Label();
            question_lbl = new Label();
            answerBtn_1 = new Button();
            answerBtn_2 = new Button();
            reset_btn = new Button();
            answerBtn_3 = new Button();
            ext_btn = new Button();
            answerBtn_4 = new Button();
            SuspendLayout();
            // 
            // titletxtlbl
            // 
            titletxtlbl.AutoSize = true;
            titletxtlbl.BackColor = Color.Transparent;
            titletxtlbl.Font = new Font("Broadway Copyist Text Ext", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            titletxtlbl.Location = new Point(334, 9);
            titletxtlbl.Name = "titletxtlbl";
            titletxtlbl.Size = new Size(199, 68);
            titletxtlbl.TabIndex = 0;
            titletxtlbl.Text = "Trivia Time!";
            // 
            // question_lbl
            // 
            question_lbl.BorderStyle = BorderStyle.Fixed3D;
            question_lbl.Font = new Font("Broadway Copyist Text Ext", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            question_lbl.Location = new Point(228, 88);
            question_lbl.Name = "question_lbl";
            question_lbl.Size = new Size(404, 76);
            question_lbl.TabIndex = 1;
            question_lbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // answerBtn_1
            // 
            answerBtn_1.Font = new Font("Broadway Copyist Text Ext", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            answerBtn_1.Location = new Point(228, 189);
            answerBtn_1.Name = "answerBtn_1";
            answerBtn_1.Size = new Size(159, 72);
            answerBtn_1.TabIndex = 2;
            answerBtn_1.UseVisualStyleBackColor = true;
            answerBtn_1.Click += answerBtn_1_Click;
            // 
            // answerBtn_2
            // 
            answerBtn_2.Font = new Font("Broadway Copyist Text Ext", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            answerBtn_2.Location = new Point(473, 189);
            answerBtn_2.Name = "answerBtn_2";
            answerBtn_2.Size = new Size(159, 72);
            answerBtn_2.TabIndex = 2;
            answerBtn_2.UseVisualStyleBackColor = true;
            answerBtn_2.Click += answerBtn_2_Click;
            // 
            // reset_btn
            // 
            reset_btn.Font = new Font("Broadway Copyist Text Ext", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point, 0);
            reset_btn.Location = new Point(12, 429);
            reset_btn.Name = "reset_btn";
            reset_btn.Size = new Size(132, 58);
            reset_btn.TabIndex = 2;
            reset_btn.Text = "Reset";
            reset_btn.UseVisualStyleBackColor = true;
            reset_btn.Click += reset_btn_Click;
            // 
            // answerBtn_3
            // 
            answerBtn_3.Font = new Font("Broadway Copyist Text Ext", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            answerBtn_3.Location = new Point(228, 281);
            answerBtn_3.Name = "answerBtn_3";
            answerBtn_3.Size = new Size(159, 72);
            answerBtn_3.TabIndex = 2;
            answerBtn_3.UseVisualStyleBackColor = true;
            answerBtn_3.Click += answerBtn_3_Click;
            // 
            // ext_btn
            // 
            ext_btn.Font = new Font("Broadway Copyist Text Ext", 23.9999981F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ext_btn.Location = new Point(711, 429);
            ext_btn.Name = "ext_btn";
            ext_btn.Size = new Size(132, 58);
            ext_btn.TabIndex = 2;
            ext_btn.Text = "Exit";
            ext_btn.UseVisualStyleBackColor = true;
            ext_btn.Click += ext_btn_Click;
            // 
            // answerBtn_4
            // 
            answerBtn_4.Font = new Font("Broadway Copyist Text Ext", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            answerBtn_4.Location = new Point(473, 281);
            answerBtn_4.Name = "answerBtn_4";
            answerBtn_4.Size = new Size(159, 72);
            answerBtn_4.TabIndex = 2;
            answerBtn_4.UseVisualStyleBackColor = true;
            answerBtn_4.Click += answerBtn_4_Click;
            // 
            // triviaGameForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(855, 499);
            Controls.Add(answerBtn_4);
            Controls.Add(answerBtn_3);
            Controls.Add(ext_btn);
            Controls.Add(reset_btn);
            Controls.Add(answerBtn_2);
            Controls.Add(answerBtn_1);
            Controls.Add(question_lbl);
            Controls.Add(titletxtlbl);
            Name = "triviaGameForm";
            Text = "Trivia Game - RK";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titletxtlbl;
        private Label question_lbl;
        private Button answerBtn_1;
        private Button answerBtn_2;
        private Button reset_btn;
        private Button answerBtn_3;
        private Button ext_btn;
        private Button answerBtn_4;
    }
}
