namespace CryptoInterface_RK
{
    public partial class cryptoForm : Form
    {
        public cryptoForm()
        {
            InitializeComponent();
        }

        private void encryptBtn_Click(object sender, EventArgs e)
        {
            //When clicked gets user message and encripts it through 2 ciphers
            string message = user_input.Text.Trim();

            IEncryptor encryptorA = new EncryptorCC();
            IEncryptor encryptorB = new EncryptorRS();

            string encryptedCC = encryptorA.Encrypt(message);
            string decryptedCC = encryptorA.Decrypt(encryptedCC);
            string encryptedRS = encryptorB.Encrypt(message);
            string decryptedRS = encryptorB.Decrypt(encryptedRS);

            //Output for Caesar Cipher
            encryptlbl_CC.Text = "Encrypted: " + encryptedCC;
            decryptlbl_CC.Text = "Decrypted: " + decryptedCC;

            //Output for Reverse and Shift
            encryptlbl_RS.Text = "Encrypted: " + encryptedRS;
            decryptlbl_RS.Text = "Decrypted: " + decryptedRS;
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            //Reset Button
            user_input.Text = "";
            encryptlbl_CC.Text = "Encrypted:";
            decryptlbl_CC.Text = "Decrypted:";
            encryptlbl_RS.Text = "Encrypted:";
            decryptlbl_RS.Text = "Decrypted:";
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            //Exit Button
            this.Close();
        }
    }
    public interface IEncryptor
    {
        //Encryption Interface
        string Encrypt(string input);
        string Decrypt(string input);
    }
    public class EncryptorCC : IEncryptor
    {
        //EncryptorCC - Caesar Cipher(Shift each character forward by 3)
        public string Encrypt(string input)
        {
            // Encrypt: Shift each character forward by 3
            return new string(input.Select(c => (char)(c + 3)).ToArray());
        }

        public string Decrypt(string input)
        {
            // Decrypt: Shift each character backward by 3
            return new string(input.Select(c => (char)(c - 3)).ToArray());
        }
    }
    public class EncryptorRS : IEncryptor
    {
        //EncryptorRS - Reverse & Shift (Shift back by 1, then reverse)
        public string Encrypt(string input)
        {
            // Encrypt: Shift each character back by 1, then reverse the whole string
            var shifted = new string(input.Select(c => (char)(c - 1)).ToArray());
            return new string(shifted.Reverse().ToArray());
        }

        public string Decrypt(string input)
        {
            // Decrypt: Reverse the string, then shift each character forward by 1
            var reversed = new string(input.Reverse().ToArray());
            return new string(reversed.Select(c => (char)(c + 1)).ToArray());
        }
    }
}
