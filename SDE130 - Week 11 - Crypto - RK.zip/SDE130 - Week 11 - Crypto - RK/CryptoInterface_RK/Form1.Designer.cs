﻿namespace CryptoInterface_RK
{
    partial class cryptoForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cryptoForm));
            label1 = new Label();
            label2 = new Label();
            user_input = new TextBox();
            label3 = new Label();
            label4 = new Label();
            encryptlbl_CC = new Label();
            decryptlbl_CC = new Label();
            encryptlbl_RS = new Label();
            decryptlbl_RS = new Label();
            encryptBtn = new Button();
            resetBtn = new Button();
            exitBtn = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Courier New", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(406, 9);
            label1.Name = "label1";
            label1.Size = new Size(603, 54);
            label1.TabIndex = 0;
            label1.Text = "Mission: Encryptable";
            // 
            // label2
            // 
            label2.Font = new Font("Courier New", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(357, 75);
            label2.Name = "label2";
            label2.Size = new Size(702, 82);
            label2.TabIndex = 0;
            label2.Text = "Type a message in the text box below and I'll encypt it with 2 different ciphers.";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // user_input
            // 
            user_input.BackColor = Color.FromArgb(192, 255, 192);
            user_input.Font = new Font("Courier New", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            user_input.Location = new Point(422, 169);
            user_input.Multiline = true;
            user_input.Name = "user_input";
            user_input.Size = new Size(567, 172);
            user_input.TabIndex = 1;
            // 
            // label3
            // 
            label3.Font = new Font("Courier New", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(125, 372);
            label3.Name = "label3";
            label3.Size = new Size(325, 40);
            label3.TabIndex = 0;
            label3.Text = "Caesar Cipher";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.Font = new Font("Courier New", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(945, 372);
            label4.Name = "label4";
            label4.Size = new Size(325, 40);
            label4.TabIndex = 0;
            label4.Text = "Reverse and Shift";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // encryptlbl_CC
            // 
            encryptlbl_CC.BackColor = Color.FromArgb(192, 255, 192);
            encryptlbl_CC.Font = new Font("Courier New", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            encryptlbl_CC.Location = new Point(12, 424);
            encryptlbl_CC.Name = "encryptlbl_CC";
            encryptlbl_CC.Size = new Size(567, 172);
            encryptlbl_CC.TabIndex = 0;
            encryptlbl_CC.Text = "Encrypted:";
            // 
            // decryptlbl_CC
            // 
            decryptlbl_CC.BackColor = Color.FromArgb(192, 255, 192);
            decryptlbl_CC.Font = new Font("Courier New", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            decryptlbl_CC.Location = new Point(12, 611);
            decryptlbl_CC.Name = "decryptlbl_CC";
            decryptlbl_CC.Size = new Size(567, 172);
            decryptlbl_CC.TabIndex = 0;
            decryptlbl_CC.Text = "Decrypted:";
            // 
            // encryptlbl_RS
            // 
            encryptlbl_RS.BackColor = Color.FromArgb(192, 255, 192);
            encryptlbl_RS.Font = new Font("Courier New", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            encryptlbl_RS.Location = new Point(817, 424);
            encryptlbl_RS.Name = "encryptlbl_RS";
            encryptlbl_RS.Size = new Size(567, 172);
            encryptlbl_RS.TabIndex = 0;
            encryptlbl_RS.Text = "Encrypted:";
            // 
            // decryptlbl_RS
            // 
            decryptlbl_RS.BackColor = Color.FromArgb(192, 255, 192);
            decryptlbl_RS.Font = new Font("Courier New", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            decryptlbl_RS.Location = new Point(817, 611);
            decryptlbl_RS.Name = "decryptlbl_RS";
            decryptlbl_RS.Size = new Size(567, 172);
            decryptlbl_RS.TabIndex = 0;
            decryptlbl_RS.Text = "Decrypted:";
            // 
            // encryptBtn
            // 
            encryptBtn.BackColor = Color.Silver;
            encryptBtn.Font = new Font("Courier New", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            encryptBtn.Location = new Point(580, 354);
            encryptBtn.Name = "encryptBtn";
            encryptBtn.Size = new Size(238, 58);
            encryptBtn.TabIndex = 2;
            encryptBtn.Text = "Encrypt";
            encryptBtn.UseVisualStyleBackColor = false;
            encryptBtn.Click += encryptBtn_Click;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.Silver;
            resetBtn.Font = new Font("Courier New", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            resetBtn.Location = new Point(648, 424);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(108, 49);
            resetBtn.TabIndex = 2;
            resetBtn.Text = "Reset";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // exitBtn
            // 
            exitBtn.BackColor = Color.Silver;
            exitBtn.Font = new Font("Courier New", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitBtn.Location = new Point(648, 487);
            exitBtn.Name = "exitBtn";
            exitBtn.Size = new Size(108, 49);
            exitBtn.TabIndex = 2;
            exitBtn.Text = "Exit";
            exitBtn.UseVisualStyleBackColor = false;
            exitBtn.Click += exitBtn_Click;
            // 
            // cryptoForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1396, 803);
            Controls.Add(exitBtn);
            Controls.Add(resetBtn);
            Controls.Add(encryptBtn);
            Controls.Add(user_input);
            Controls.Add(label4);
            Controls.Add(decryptlbl_RS);
            Controls.Add(decryptlbl_CC);
            Controls.Add(encryptlbl_RS);
            Controls.Add(encryptlbl_CC);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "cryptoForm";
            Text = "Crypto Interface - RK";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox user_input;
        private Label label3;
        private Label label4;
        private Label encryptlbl_CC;
        private Label decryptlbl_CC;
        private Label encryptlbl_RS;
        private Label decryptlbl_RS;
        private Button encryptBtn;
        private Button resetBtn;
        private Button exitBtn;
    }
}
